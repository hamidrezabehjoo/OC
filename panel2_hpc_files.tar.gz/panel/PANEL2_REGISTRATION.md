# Panel 2 registration — TP16 holdout test (amendment to the prospective panel protocol v2.5)

**Status: DRAFT — commit and push BEFORE the first panel-2 run. The commit
timestamp is the prospective timestamp; any holdout output that predates
this commit invalidates the design.**

This amendment registers the second prospective panel. It changes only
what panel 1 (tag `panel-v2.5`, commit `e0dcd2e`) showed to be broken or
suboptimal, and it states every change and its evidence *before* the
holdout data exist.

## 1. Population (frozen)

All 16 ready TP16 membrane-transporter targets from `panel/targets.csv`
(AFsample2 Table S3), copied verbatim into `panel/targets2.csv`:

tm_0287, slc1a1_out, slc39, ptsg, mdfa, mfsd2a_out, wlab_out,
a5u30_003247, pf0708, murj, aac3_out, tt_c0976, spf1, melb,
cyme_cmd148c_out, tm_0287v2

These targets were never screened, intervened, or evaluated during
panel 1 or during method development. No target may be added to or
dropped from this list after the first screen run; spf1 (1239 aa) is
included despite its cost because dropping it after seeing panel-1
outcomes would be outcome-contingent selection.

## 2. Hypotheses and endpoints (frozen)

- **H1 (efficacy).** Over reach-gated diagnosed (damp/boost) targets,
  the ctrl arm increases target-basin occupancy vs stock: pooled
  one-sided exact Wilcoxon on per-target signed shifts, plus per-target
  success fraction (5/5 seed direction + seed-level bootstrap CI
  excluding 0), Wilson 95% CI. Damp branch is primary; boost branch is
  reported descriptively.
- **H2 (sign law).** Paired ctrl-vs-contra one-sided exact Wilcoxon;
  contra false-positive rate with Wilson CI (the sign law predicts 0).
  Holm correction over the {RMSD-rule, TM-rule} analyses applies if the
  D1 geometry diagnostic flags, exactly as in panel 1.
- **H3 (no harm).** Healthy-diagnosed targets receive both arms (cap 5,
  fixed-seed(7) draw if more); harm = expected-state occupancy decrease
  with one-sided Fisher p < 0.05 on either arm.

Per-target success criteria, the D1 diagnostic, the bootstrap, and the
power rule (< 5 members = inconclusive) are unchanged from protocol
v2.5 and are implemented by `panel/analyze_panel2.py`, a copy of the
frozen `panel/analyze_panel.py` with only the endpoint definitions
changed.

## 3. Frozen settings (identical to panel 1 unless listed)

N=100 diffusion samples; 200 sampling steps; screen seeds 42 1 2;
arm seeds 42 1 2 7 13; NU_TW=0.5; `--use_potentials`; PDB output;
per-target frozen MSA (panel_msa/<name>.a3m, frozen from the first
stock run); same eval and diagnose scripts as panel 1.

**Changes, with their pre-registered justifications:**

1. **Damp strength α = 0.25** (was 0.5). Evidence: ADK dev dose ladder
   (open occupancy 15.0% → 17.3% → 29.0% → 43.7% at α = 1/0.75/0.5/0.25;
   monotone, saturating) and the post-hoc damp025 dev matrix on panel-1
   targets (p71447: 2.7% → 22.6% at α=0.25, monotone; q9z4n6 saturates
   by 0.5). All evidence is from dev/panel-1 data, none from the
   holdout. The value 0.25 is frozen here and must not be re-tuned on
   holdout outcomes.
2. **Reach gate.** No arm runs toward a basin the stock ensemble never
   reaches (best-of-stock RMSD to the target reference > basin radius
   min(3.5 Å, 0.5·ref-separation)). Panel-1 evidence: all six
   unreachable-target interventions returned exactly 0.000 occupancy at
   every seed and every α. Gated targets are reported as
   screened-not-intervened and do not enter H1/H2.
3. **No degrade arm.** The panel-1 manipulation check failed 0/2
   (depth-32 MSA did not re-diagnose as boost); the arm is dropped.
4. **Boost is demoted to a control role.** On damp-diagnosed targets,
   boost α=2.5 is the contra arm (H2). Boost-diagnosed targets still
   receive boost α=2.5 as ctrl, but that branch is descriptive
   (panel-1 produced two directional inversions under boost
   prescriptions).

## 4. Analysis plan (frozen)

`./panel/run_panel2.sh analyze` → `panel/analyze_panel2.py`, printing
H1/H2/H3, the D1 geometry and reachability checks, branch fractions,
and the reach-gate tally; `panel/panel2_summary.csv` is the machine-
readable record. Any analysis beyond this file is labelled exploratory
and post-hoc in the manuscript.

## 5. Freeze procedure

1. Commit this file + `targets2.csv` + `run_panel2.sh` +
   `analyze_panel2.py` + `make_manifest2.py` + `submit_panel2.sh`;
   push. (This commit is the prospective timestamp.)
2. `qsub -v PHASE=fetch submit_panel2.sh` (or run fetch on a login node
   if compute nodes have no network).
3. `qsub -v PHASE=screen submit_panel2.sh`.
4. `python3 panel/make_manifest2.py` — write the panel-2 freeze
   (inputs + frozen MSAs); commit `MANIFEST2.md5`.
5. `qsub -v PHASE=intervene submit_panel2.sh`, then
   `qsub -v PHASE=analyze submit_panel2.sh`.
6. Copy all eval CSVs, job logs, and the 16 new `panel_msa/*.a3m` back
   into the repo (scratch purges at 30 days); commit.

## 6. Post-archival fields (fill in after tagging; this file stays unpinned)

- Repo URL:
- Release / tag: panel-v3 (created after step 4)
- Zenodo DOI:
- Registration date:
