#!/usr/bin/env bash
#PBS -N diffusion_panel2
#PBS -P 11004454
#PBS -q normal
#PBS -l select=1:ncpus=8:ngpus=2
#PBS -l walltime=24:00:00
#PBS -j oe
# ============================================================================
# Panel-2 job (registered holdout, TP16) — NSCC ASPIRE 2A.
# Submit from the repo root (~/DiffusionControl):
#
#   qsub -v PHASE=fetch      submit_panel2.sh   # refs/yamls (needs network; else run on login node)
#   qsub -v PHASE=screen     submit_panel2.sh   # stock screen + diagnosis + reach data
#   qsub -v PHASE=intervene  submit_panel2.sh   # controlled arms (5 seeds, damp a=0.25)
#   qsub -v PHASE=analyze    submit_panel2.sh   # H1/H2/H3 stats + verdicts
#   qsub -v PHASE=all        submit_panel2.sh   # screen + intervene + analyze, in order
#
# PRECONDITION: panel/PANEL2_REGISTRATION.md committed and pushed BEFORE
# the first screen run. The git tag is the prospective timestamp.
#
# Everything is resumable: finished seeds print [skip]; a walltime kill
# means: fix the cause, resubmit the same PHASE. Nothing redone.
#
# Keep ngpus= above in sync with reality — GPUS is auto-detected below.
# TP16 targets are 322-1239 aa (larger than panel-1's): keep
# BOLTZ_EXTRA_ARGS="--max_parallel_samples 30" (or 34) on.
# ============================================================================
set -euo pipefail

PHASE="${PHASE:-screen}"
case "$PHASE" in fetch|screen|intervene|analyze|all) ;; *)
    echo "FATAL: PHASE must be fetch|screen|intervene|analyze|all (got '$PHASE')" >&2
    exit 2 ;;
esac

SCRATCH="${SCRATCH:-/scratch/users/industry/ism/behjoo}"
ENV_PREFIX="${ENV_PREFIX:-$SCRATCH/envs/boltz_ctrl}"
REPO="${REPO:-$HOME/DiffusionControl}"

# caches on scratch (batch jobs do not read ~/.bashrc)
export PIP_CACHE_DIR="$SCRATCH/pipcache" TMPDIR="$SCRATCH/tmp" XDG_CACHE_HOME="$SCRATCH/cache"

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_PREFIX"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib/python3.11/site-packages/nvidia/nvrtc/lib:${LD_LIBRARY_PATH:-}"

cd "$REPO"

# knobs — GPUS follows the actual allocation; chunking avoids OOM >= ~450 aa
GPUS="${GPUS:-$(nvidia-smi -L 2>/dev/null | grep -c '^GPU' || echo 1)}"
export GPUS
export BOLTZ_EXTRA_ARGS="${BOLTZ_EXTRA_ARGS:---max_parallel_samples 30}"
# frozen by the panel-2 registration (do NOT set): N STEPS SEEDS CTRL_SEEDS

echo "== panel-2 job =="
echo "  job     : ${PBS_JOBID:-interactive}"
echo "  node    : $(hostname)   phase: $PHASE   gpus: $GPUS"
echo "  extra   : ${BOLTZ_EXTRA_ARGS:-<none>}"
nvidia-smi --query-gpu=index,name,memory.total --format=csv,noheader || true

echo "== registration check =="
if [ "$PHASE" != "fetch" ]; then
    git log --oneline -1 -- panel/PANEL2_REGISTRATION.md || true
    git diff --quiet panel/PANEL2_REGISTRATION.md && git diff --cached --quiet panel/PANEL2_REGISTRATION.md \
        || { echo "FATAL: PANEL2_REGISTRATION.md has uncommitted changes - commit BEFORE running"; exit 1; }
fi

echo "== freeze checks =="
python3 panel/make_manifest.py --verify    # panel-1 freeze must stay intact
python3 panel/make_manifest2.py --verify   # panel-2 freeze (once written)

case "$PHASE" in
    fetch)     bash panel/run_panel2.sh fetch ;;
    screen)    bash panel/run_panel2.sh screen ;;
    intervene) bash panel/run_panel2.sh intervene ;;
    analyze)   bash panel/run_panel2.sh analyze ;;
    all)       bash panel/run_panel2.sh screen \
            && python3 panel/make_manifest2.py \
            && bash panel/run_panel2.sh intervene \
            && bash panel/run_panel2.sh analyze ;;
esac

echo "== done: $PHASE =="
echo "REMINDER: scratch purges at 30 days — copy results/, eval_*.csv and"
echo "          panel_msa/<tp16>.a3m back to the paper repo now."
