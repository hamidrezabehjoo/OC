#!/usr/bin/env python3
"""Write or verify the PANEL-2 freeze manifest (PANEL2_REGISTRATION.md).

    python3 panel/make_manifest2.py            # write panel/MANIFEST2.md5
    python3 panel/make_manifest2.py --verify   # check current files against it

Panel-2 counterpart of make_manifest.py. Pins only what the panel-2
holdout test depends on:

  - panel/targets2.csv, panel/run_panel2.sh, panel/analyze_panel2.py
  - the shared frozen machinery (eval_panel.py, panel_diagnose.py,
    diffusionv2.py -- already pinned by panel/MANIFEST.md5; re-pinned
    here so MANIFEST2 is self-contained)
  - panel/fetch_report2.csv and the 16 holdout targets' yamls, prepared
    references, and frozen MSAs (MSAs exist only AFTER the screen phase;
    write the manifest once after screening, verify ever after)

PANEL2_REGISTRATION.md is deliberately NOT pinned (same design as
panel-1 REGISTRATION.md): the post-archival fields (repo URL, release,
Zenodo DOI, date) are filled in after the tag, and editing a pinned file
would invalidate the tag the registration documents. The tag panel-v3
is the timestamp.

Write-timing rule: run `make_manifest2.py` (write mode) ONCE, after
fetch+screen complete and before intervene. Never re-run write mode
after arms have started.
"""

import argparse
import csv
import hashlib
import os
import sys

MANIFEST = os.path.join("panel", "MANIFEST2.md5")

FIXED = [
    "panel/targets2.csv",
    "panel/run_panel2.sh",
    "panel/analyze_panel2.py",
    "panel/eval_panel.py",
    "panel/panel_diagnose.py",
    "panel/fetch_report2.csv",
    "diffusionv2.py",
]


def md5(path):
    return hashlib.md5(open(path, "rb").read()).hexdigest()


def collect():
    files = list(FIXED)
    for r in csv.DictReader(open(os.path.join("panel", "targets2.csv"))):
        n = r["name"]
        files += [
            os.path.join("yamls", f"{n}.yaml"),
            os.path.join("panel_data", f"{n}_ref1.pdb"),
            os.path.join("panel_data", f"{n}_ref2.pdb"),
            os.path.join("panel_msa", f"{n}.a3m"),   # present after screen
        ]
    return sorted(set(files))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()

    if not args.verify:
        files = [f for f in collect() if os.path.exists(f)]
        missing = [f for f in collect() if not os.path.exists(f)]
        with open(MANIFEST, "w") as f:
            for p in files:
                f.write(f"{md5(p)}  {p}\n")
        print(f"wrote {MANIFEST} ({len(files)} files)")
        if missing:
            print("NOTE: not yet present (run write mode again only if NO "
                  "arm has started):")
            for p in missing:
                print(f"  pending {p}")
        return

    if not os.path.exists(MANIFEST):
        # before the panel-2 freeze this is expected; panel-1's manifest
        # is verified separately by the submit script
        print(f"{MANIFEST} not found (pre-freeze; nothing to verify)")
        return
    bad = missing = 0
    for line in open(MANIFEST):
        line = line.rstrip("\n")
        if not line:
            continue
        want, path = line.split(None, 1)
        path = path.strip()
        if not os.path.exists(path):
            print(f"MISSING  {path}")
            missing += 1
        elif md5(path) != want:
            print(f"CHANGED  {path}")
            bad += 1
    if bad or missing:
        sys.exit(f"VERIFY FAILED: {bad} changed, {missing} missing")
    print("manifest2 OK: all pinned panel-2 files match")


if __name__ == "__main__":
    main()
