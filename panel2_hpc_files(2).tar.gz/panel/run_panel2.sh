#!/usr/bin/env bash
# Panel-2 driver: registered holdout test (TP16 transporters, 16 targets).
# Protocol: panel/PANEL2_REGISTRATION.md (MUST be committed before any run).
# Panel-1 protocol remains panel/prospective_test_panel_protocol.md (v2.5).
#
#   ./panel/run_panel2.sh fetch                        # sequences, refs, yamls (staged; never touches panel-1 pinned files)
#   ./panel/run_panel2.sh screen                       # stock screen: 100 x 3 seeds per target + diagnosis + reach gate
#   ./panel/run_panel2.sh intervene                    # frozen arms on reachable diagnosed targets + healthy no-harm controls
#   ./panel/run_panel2.sh analyze                      # panel-2 summary (H1 efficacy / H2 sign-law / H3 no-harm)
#
# Filters (any phase):   --only name1,name2
# Execution knobs (env): GPUS=1 (screen: split targets across cards)
#                        BOLTZ_EXTRA_ARGS="" (e.g. "--max_parallel_samples 30")
# Frozen (PANEL2_REGISTRATION.md; do NOT change): N=100 STEPS=200
#     SEEDS="42 1 2"  CTRL_SEEDS="42 1 2 7 13"  N_HEALTHY_CONTROLS=5
#     DAMP_ALPHA=0.25  BOOST_ALPHA=2.5  NU_TW=0.5
#
# Differences vs panel 1 (registered, not tunable):
#   * damp strength is 0.25 (from the ADK dose ladder + damp025 dev matrix;
#     the response saturates by alpha=0.25)
#   * REACH GATE: no arm runs toward a basin the stock ensemble never
#     visits (panel-1 lesson: 6/6 such interventions returned exact zeros)
#   * no degrade arm (panel-1 manipulation check failed 0/2; dropped by registration)
#   * boost remains as the contra arm on damp-diagnosed targets and as the
#     ctrl arm on boost-diagnosed targets (secondary, descriptive branch)
#
# Per target <name> (same conventions as panel 1; names are disjoint from
# panel 1 so no eval file collides):
#   yamls/<name>.yaml                        fetch (staged, then merged)
#   panel_data/<name>_ref1.pdb, _ref2.pdb    fetch (renumbered)
#   panel_msa/<name>.a3m                     screen (MSA frozen for all arms)
#   results_<name>_{stock,ctrl,contra}_s<seed>/
#   eval_<name>_{stock,ctrl,contra}_s<seed>.csv
#   panel/panel2_diagnosis.csv, panel/panel2_summary.csv
#   panel/fetch_report2.csv, panel/healthy_controls2.txt
#
# Prerequisites: patched Boltz-2 env (diffusionv2.py must contain NU_ALPHA;
# checked before any controlled run).

set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PHASE="${1:-}"
ONLY=""
shift || true
while [ $# -gt 0 ]; do
    case "$1" in
        --only) ONLY="$2"; shift 2 ;;
        *) echo "unknown option $1" >&2; exit 1 ;;
    esac
done

TARGETS_CSV="panel/targets2.csv"
DIAG_CSV="panel/panel2_diagnosis.csv"
FETCH_REP="panel/fetch_report2.csv"
HEALTHY_TXT="panel/healthy_controls2.txt"
SUMMARY_CSV="panel/panel2_summary.csv"

N=${N:-100}; STEPS=${STEPS:-200}
SEEDS=${SEEDS:-"42 1 2"}                    # stock screen (diagnosis)
CTRL_SEEDS=${CTRL_SEEDS:-"42 1 2 7 13"}     # controlled/contra arms
N_HEALTHY_CONTROLS=${N_HEALTHY_CONTROLS:-5}
DAMP_ALPHA=0.25    # frozen by panel-2 registration; do not tune per target
BOOST_ALPHA=2.5    # unchanged from panel 1 (contra / secondary branch)
BOLTZ_EXTRA_ARGS=${BOLTZ_EXTRA_ARGS:-""}

BIGCACHE="${BIGCACHE:-$HOME}"
export BOLTZ_CACHE="${BOLTZ_CACHE:-$BIGCACHE/boltz_cache}"
export TRITON_CACHE_DIR="${TRITON_CACHE_DIR:-$BIGCACHE/triton_cache}"
export TORCHINDUCTOR_CACHE_DIR="${TORCHINDUCTOR_CACHE_DIR:-$BIGCACHE/torchinductor_cache}"
export CUDA_CACHE_PATH="${CUDA_CACHE_PATH:-$BIGCACHE/cuda_cache}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$BIGCACHE/xdg_cache}"
mkdir -p "$BOLTZ_CACHE" panel_msa

TARGETS=$(python3 - "$ONLY" <<'EOF'
import csv, sys
only = set(sys.argv[1].split(",")) if sys.argv[1] else None
for r in csv.DictReader(open("panel/targets2.csv")):
    if r["status"] != "ready":
        continue
    if only and r["name"] not in only:
        continue
    print(r["name"], r["foldswitch"], r["expected_state"])
EOF
)
[ -n "$TARGETS" ] || { echo "no targets selected" >&2; exit 1; }

yaml_of()    { echo "yamls/$1.yaml"; }
pred_dir()   { echo "$1/boltz_results_$2/predictions/$2"; }
# boltz names output dirs after the YAML filename STEM (see run_panel.sh).
yaml_stem() { local b; b=$(basename "$1"); echo "${b%.yaml}"; }
basin_rule() { [ "$2" = "1" ] && echo tm || echo rmsd; }

run_eval() { # $1 results dir, $2 name, $3 foldswitch, $4 tag, $5 yaml stem
    python3 panel/eval_panel.py --pred_dir "$(pred_dir "$1" "$5")" \
        --ref1 "panel_data/$2_ref1.pdb" --ref2 "panel_data/$2_ref2.pdb" \
        --basin_rule "$(basin_rule "$2" "$3")" --escape_rmsd auto \
        --tag "$4" --out "eval_$2_$4.csv"
}

patch_gate() {
    local f n
    f=$(python3 -c "import boltz, os; print(os.path.join(os.path.dirname(boltz.__file__),'model','modules','diffusionv2.py'))")
    n=$(grep -c NU_ALPHA "$f" || true)
    if [ "$n" -eq 0 ]; then
        echo "FATAL: $f has no NU_ALPHA hook - controlled arm would silently be stock." >&2
        echo "Apply the patch first:  cp diffusionv2.py $f" >&2
        exit 1
    fi
}

# freeze the MSA from the first stock run so every later arm of this target
# uses byte-identical evolutionary input (same freeze discipline as panel 1)
freeze_msa() { # $1 name, $2 first results dir
    [ -s "panel_msa/$1.a3m" ] && return 0
    local a3m
    a3m=$(find "$2" -name "*.a3m" | head -1 || true)
    if [ -n "$a3m" ]; then
        cp "$a3m" "panel_msa/$1.a3m"
        python3 - "$1" <<'EOF'
import sys
p = f"panel_msa/{sys.argv[1]}.a3m"
d = open(p, "rb").read()
if d.endswith(b"\x00") and d.count(b"\x00") == 1:
    open(p, "wb").write(d[:-1])
    print(f"  freeze_msa: stripped trailing NUL (boltz writer artifact) from {p}")
elif b"\x00" in d:
    print(f"  WARNING: {p} contains NUL bytes beyond the trailing artifact -", file=sys.stderr)
    print(f"  inspect before running arms of this target", file=sys.stderr)
EOF
        echo "  MSA frozen: $(md5sum "panel_msa/$1.a3m" | cut -c1-12) panel_msa/$1.a3m"
    else
        echo "  WARNING: no .a3m found under $2 - ctrl arms will call the MSA server again" >&2
    fi
}

# yaml with the frozen MSA wired in; sets MSA_YAML and MSA_FLAG. Must NOT
# be called via $(...) (subshell loses the flag; see run_panel.sh).
msa_yaml() { # $1 name
    if [ -s "panel_msa/$1.a3m" ]; then
        if python3 -c "import sys; sys.exit(1 if b'\x00' in open('panel_msa/$1.a3m','rb').read() else 0)"; then
            sed "/      sequence:/a\\      msa: panel_msa/$1.a3m" "$(yaml_of "$1")" > "yamls/$1.msa.yaml"
            MSA_YAML="yamls/$1.msa.yaml"; MSA_FLAG=""
        else
            echo "  CORRUPT: panel_msa/$1.a3m has NUL bytes - repair or re-fetch, then rerun" >&2
            MSA_YAML=""; MSA_FLAG=""
        fi
    else
        MSA_YAML=$(yaml_of "$1"); MSA_FLAG="--use_msa_server"
    fi
}

run_arm() { # $1 name, $2 foldswitch, $3 tag(ctrl/contra), $4 alpha
    local name=$1 fs=$2 tag=$3 alpha=$4
    local y mf stem
    msa_yaml "$name"; y=$MSA_YAML; mf=$MSA_FLAG; stem=$(yaml_stem "$y")
    [ -n "$y" ] || { echo "[skip] $name $tag: frozen MSA corrupt (see above)"; return 1; }
    for s in $CTRL_SEEDS; do
        if [ -s "eval_${name}_${tag}_s${s}.csv" ]; then
            echo "[skip] $name $tag seed $s: exists"; continue
        fi
        local res="results_${name}_${tag}_s${s}"
        if [ -d "$(pred_dir "$res" "$stem")" ]; then
            echo "[reuse] $name $tag seed $s: predictions exist, eval only"
        else
            echo "=== $name $tag alpha=$alpha tw=0.5 seed $s ==="
            NU_ALPHA="$alpha" NU_TW=0.5 \
            boltz predict "$y" $mf --use_potentials < /dev/null \
                --diffusion_samples "$N" --sampling_steps "$STEPS" $BOLTZ_EXTRA_ARGS \
                --output_format pdb --seed "$s" --cache "$BOLTZ_CACHE" \
                --out_dir "$res" --override \
                || { echo "[FAIL boltz] $name $tag seed $s"; continue; }
        fi
        run_eval "$res" "$name" "$fs" "${tag}_s${s}" "$stem" \
            || echo "[FAIL eval] $name $tag seed $s"
    done
}

case "$PHASE" in

fetch)
    # Staged fetch: fetch_panel.py rewrites panel/fetch_report.csv (pinned
    # panel-1 file), so it must NOT run with --root . . Fetch into a staging
    # dir, then merge NEW files only (cp -n never overwrites a pinned file).
    STAGE="${TMPDIR:-/tmp}/panel2_fetch"
    rm -rf "$STAGE"; mkdir -p "$STAGE/panel"
    python3 panel/fetch_panel.py --targets "$TARGETS_CSV" --root "$STAGE" --include-optional ${ONLY:+--only $ONLY}
    [ -f "$STAGE/panel/fetch_report.csv" ] || { echo "fetch produced no report" >&2; exit 1; }
    # merge: new yamls + refs (tp16 names are disjoint from panel 1)
    ( cd "$STAGE" && find yamls panel_data -type f 2>/dev/null | while read -r f; do
        if [ -e "$ROOT/$f" ]; then
            cmp -s "$f" "$ROOT/$f" || { echo "CONFLICT: $f exists and differs - refusing to overwrite" >&2; exit 1; }
        else
            mkdir -p "$ROOT/$(dirname "$f")"; cp "$f" "$ROOT/$f"
        fi
      done )
    # fetch_report2.csv: merge with any previous panel-2 report rows
    python3 - "$STAGE/panel/fetch_report.csv" <<'EOF'
import csv, os, sys
new = {r["name"]: r for r in csv.DictReader(open(sys.argv[1]))}
path = "panel/fetch_report2.csv"
old = {}
if os.path.exists(path):
    old = {r["name"]: r for r in csv.DictReader(open(path))}
old.update(new)
fields = ["name","set","L_input","matched_ref1","matched_ref2","shared",
          "id1","id2","ref_rmsd","rmsd_table","warning"]
with open(path, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    for n in sorted(old): w.writerow(old[n])
print(f"wrote {path} ({len(old)} targets)")
EOF
    ;;

screen)
    N_GPUS=${GPUS:-1}
    TGT="$TARGETS" python3 - "$N_GPUS" <<'EOF'
import csv, os, sys
n = int(sys.argv[1])
length = {r["name"]: int(r["length"]) if r["length"].strip().isdigit() else 0
          for r in csv.DictReader(open("panel/targets2.csv"))}
rows = [l.split() for l in os.environ["TGT"].splitlines() if l.strip()]
load = [0] * n
lists = [[] for _ in range(n)]
for r in sorted(rows, key=lambda r: -length.get(r[0], 0)):
    i = min(range(n), key=lambda j: load[j])
    lists[i].append(" ".join(r))
    load[i] += length.get(r[0], 0)
for i, lst in enumerate(lists):
    with open(f"/tmp/panel2_screen_w{i}.txt", "w") as fh:
        fh.write("\n".join(lst) + ("\n" if lst else ""))
    print(f"worker {i}: {[l.split()[0] for l in lst]} (load {load[i]} res)", file=sys.stderr)
EOF

    screen_worker() { # $1 worker list file
        while read -r name fs exp <&3; do
            [ -f "$(yaml_of "$name")" ] || { echo "[skip] $name: $(yaml_of "$name") missing (run fetch)"; continue; }
            # MSA strategy (2026-10-14, execution-only fix): reuse the
            # frozen MSA when present; only targets without one call the
            # ColabFold server. The public server rate-limits/times out
            # under load (panel-2 screen job 142956 lost 12/14 targets to
            # connect/read timeouts); freezing from the FIRST successful
            # seed (not only seed 42 as in panel 1) makes progress
            # accumulate across resubmissions. MSA content is unchanged -
            # same server, same sequence - so this is not a protocol change.
            msa_yaml "$name"; y=$MSA_YAML; mf=$MSA_FLAG
            [ -n "$y" ] || { echo "[skip] $name: frozen MSA corrupt"; continue; }
            stem=$(yaml_stem "$y")
            for s in $SEEDS; do
                if [ -s "eval_${name}_stock_s${s}.csv" ]; then
                    echo "[skip] $name seed $s: screen CSV exists"; continue
                fi
                echo "=== screen $name (seed $s, $N samples, gpu ${CUDA_VISIBLE_DEVICES:-default}) ==="
                boltz predict "$y" $mf --use_potentials < /dev/null \
                    --diffusion_samples "$N" --sampling_steps "$STEPS" $BOLTZ_EXTRA_ARGS \
                    --output_format pdb --seed "$s" --cache "$BOLTZ_CACHE" \
                    --out_dir "results_${name}_stock_s${s}" --override \
                    || { echo "[FAIL boltz] $name seed $s"; continue; }
                run_eval "results_${name}_stock_s${s}" "$name" "$fs" "stock_s${s}" "$stem" \
                    || { echo "[FAIL eval] $name seed $s"; continue; }
                freeze_msa "$name" "results_${name}_stock_s${s}"
            done
        done 3< "$1"
    }

    if [ "$N_GPUS" -le 1 ]; then
        screen_worker /tmp/panel2_screen_w0.txt
    else
        PIDS=""
        for i in $(seq 0 $((N_GPUS-1))); do
            ( export CUDA_VISIBLE_DEVICES=$i; screen_worker "/tmp/panel2_screen_w$i.txt" ) \
                > "screen2_gpu$i.log" 2>&1 &
            PIDS="$PIDS $!"
            echo "[worker $i] GPU $i -> screen2_gpu$i.log (pid $!)"
        done
        rc=0
        for p in $PIDS; do wait "$p" || rc=1; done
        for i in $(seq 0 $((N_GPUS-1))); do
            echo "[worker $i] failures: $(grep -c '^\[FAIL' "screen2_gpu$i.log" 2>/dev/null || true) (screen2_gpu$i.log)"
        done
        [ "$rc" -eq 0 ] || echo "WARNING: a worker exited non-zero; check screen2_gpu*.log" >&2
    fi

    # Serial diagnosis pass (same whole-file race reasoning as panel 1),
    # written to the PANEL-2 diagnosis table.
    while read -r name fs exp <&3; do
        csvs=""; dirs=""; missing=0
        for s in $SEEDS; do
            csvs="$csvs eval_${name}_stock_s${s}.csv"
            dirs="$dirs $(pred_dir results_${name}_stock_s${s} "$name")"
            [ -s "eval_${name}_stock_s${s}.csv" ] || missing=1
        done
        if [ "$missing" -eq 1 ]; then
            echo "[incomplete] $name: seed CSV(s) missing - rerun screen to retry (log above / screen2_gpu*.log)"
            continue
        fi
        python3 panel/panel_diagnose.py --name "$name" \
            --csvs $csvs --pred_dirs $dirs \
            --basin_rule "$(basin_rule "$name" "$fs")" \
            --expected "$([ "$exp" = "ref2" ] && echo closed || echo open)" \
            --out "diagnosis_${name}.txt" \
            --report_csv "$DIAG_CSV"
    done 3<<< "$TARGETS"
    echo; echo "=== screen done; $DIAG_CSV: ==="
    column -s, -t "$DIAG_CSV" 2>/dev/null || cat "$DIAG_CSV"
    ;;

intervene)
    patch_gate
    [ -f "$DIAG_CSV" ] || { echo "run screen first" >&2; exit 1; }
    DAMP_ALPHA="$DAMP_ALPHA" BOOST_ALPHA="$BOOST_ALPHA" \
    DIAG_CSV="$DIAG_CSV" FETCH_REP="$FETCH_REP" HEALTHY_TXT="$HEALTHY_TXT" \
    python3 - "$N_HEALTHY_CONTROLS" <<'EOF' > /tmp/panel2_interventions.txt
import csv, glob, os, random, sys

cap = int(sys.argv[1])
damp_a = os.environ["DAMP_ALPHA"]; boost_a = os.environ["BOOST_ALPHA"]
diag_csv = os.environ["DIAG_CSV"]; fetch_rep = os.environ["FETCH_REP"]
healthy_txt = os.environ["HEALTHY_TXT"]

refrmsd = {}
try:
    for r in csv.DictReader(open(fetch_rep)):
        try:
            refrmsd[r["name"]] = float(r["ref_rmsd"])
        except (ValueError, KeyError):
            pass
except FileNotFoundError:
    print("# WARNING: no fetch_report2.csv - reach gate cannot run; refusing to plan arms", file=sys.stderr)
    sys.exit(1)

def min_rmsd_to_refs(name):
    m1 = m2 = float("inf")
    for p in sorted(glob.glob(f"eval_{name}_stock_s*.csv")):
        with open(p) as f:
            for r in csv.DictReader(f):
                try:
                    m1 = min(m1, float(r["rmsd_open"]))
                    m2 = min(m2, float(r["rmsd_closed"]))
                except (ValueError, KeyError):
                    pass
    return m1, m2

# REACH GATE (registered, panel-2 amendment): an arm toward a basin the
# stock ensemble never reaches returned exact zeros 6/6 times in panel 1.
# Skip arms whose TARGET basin reference is unreachable; report the target
# as reach-gated (it still counts in the screened tally, not in H1/H2).
def reach_ok(name, basin):   # basin: "open" -> ref1, "closed" -> ref2
    rr = refrmsd.get(name, float("nan"))
    if rr != rr:
        return True, "no ref_rmsd (gate inapplicable)"
    radius = min(3.5, 0.5 * rr)
    m1, m2 = min_rmsd_to_refs(name)
    best = m1 if basin == "open" else m2
    if best > radius:
        return False, f"target basin unreachable (best {best:.2f} > radius {radius:.2f})"
    return True, f"reachable (best {best:.2f} <= radius {radius:.2f})"

planned, gated, healthy_primary = [], [], []
for r in csv.DictReader(open(diag_csv)):
    name, verdict = r["name"], r["verdict"]
    if verdict not in ("damp", "boost", "healthy"):
        continue
    if verdict == "healthy":
        healthy_primary.append(name)
        continue
    # target basin: damp -> expected state; boost -> minority basin.
    # panel_diagnose.csv carries the expected column; minority is derived
    # from stock occupancies in the diagnosis row.
    # NOTE: basin label "open" = ref1 basin, "closed" = ref2 basin
    # (eval_panel convention; for tp16 ref1=inward, ref2=outward).
    if verdict == "damp":
        basin = r["expected"]
        ctrl_a, contra_a = damp_a, boost_a
    else:
        s1, s2 = float(r["frac_ref1"]), float(r["frac_ref2"])
        basin = "open" if s1 <= s2 else "closed"
        ctrl_a, contra_a = boost_a, damp_a   # secondary branch (descriptive)
    ok, why = reach_ok(name, basin)
    if not ok:
        gated.append(f"{name}: {verdict} -> {basin} {why} -- NO ARMS (reach gate)")
        continue
    planned.append((name, "ctrl", ctrl_a))
    planned.append((name, "contra", contra_a))

pick = sorted(healthy_primary)
if len(pick) > cap:
    pick = sorted(random.Random(7).sample(pick, cap))
    note = f"fixed-seed(7) draw {pick} from {sorted(healthy_primary)}"
else:
    note = "all healthy targets" if pick else "none"
with open(healthy_txt, "w") as fh:
    fh.write(f"panel-2 healthy no-harm controls ({note}), cap={cap}\n")
    for n in pick:
        fh.write(n + "\n")
print(f"# healthy controls ({note}): {pick}", file=sys.stderr)
for g in gated:
    print(f"# reach-gated: {g}", file=sys.stderr)
for name, tag, alpha in planned:
    print(name, tag, alpha)
for n in pick:   # no-harm: both directions at the frozen strengths
    print(n, "ctrl", damp_a)
    print(n, "contra", boost_a)
EOF
    while read -r name tag alpha <&3; do
        [ -n "$name" ] || continue
        if [ -n "$ONLY" ] && [[ ",$ONLY," != *",$name,"* ]]; then continue; fi
        fs=$(awk -F, -v n="$name" '$1==n {print $12}' "$TARGETS_CSV")
        run_arm "$name" "$fs" "$tag" "$alpha"
    done 3< /tmp/panel2_interventions.txt
    echo "intervene done. Next: ./panel/run_panel2.sh analyze"
    ;;

analyze)
    python3 panel/analyze_panel2.py --targets "$TARGETS_CSV" \
        --diag "$DIAG_CSV" --fetch_report "$FETCH_REP" --out "$SUMMARY_CSV" \
        --seeds $SEEDS --ctrl_seeds $CTRL_SEEDS
    ;;

*)
    echo "usage: $0 {fetch|screen|intervene|analyze} [--only a,b]" >&2
    echo "  env knobs: GPUS=N (screen: split targets across N cards), BOLTZ_EXTRA_ARGS, N, SEEDS, CTRL_SEEDS" >&2
    echo "  frozen by registration: DAMP_ALPHA=0.25 BOOST_ALPHA=2.5 NU_TW=0.5" >&2
    exit 1 ;;
esac
